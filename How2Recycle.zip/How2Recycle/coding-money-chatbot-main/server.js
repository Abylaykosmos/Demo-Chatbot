const express = require('express');
const { GoogleGenerativeAI, HarmCategory, HarmBlockThreshold } = require('@google/generative-ai');
const dotenv = require('dotenv').config();

const app = express();
const port = process.env.PORT || 3000;
app.use(express.json());

const MODEL_NAME = 'gemini-pro';
const API_KEY = process.env.API_KEY;

async function runChat(userInput) {
  const genAI = new GoogleGenerativeAI(API_KEY);
  const model = genAI.getGenerativeModel({ model: MODEL_NAME });

  const generationConfig = {
    temperature: 0.9,
    topK: 1,
    topP: 1,
    maxOutputTokens: 2048,
  };

  const safetySettings = [
    {
      category: HarmCategory.HARM_CATEGORY_HARASSMENT,
      threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    },
    {
      category: HarmCategory.HARM_CATEGORY_HATE_SPEECH,
      threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    },
    {
      category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
      threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    },
    {
      category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
      threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    },
  ];

  const parts = [
    { text: "Welcome to [How2Recycle]! We're here to make recycling and reusing a breeze. If you have any questions about how to recycle specific items, just ask our AI recycling expert. Let's dive in and make a positive impact on the planet together!" },
    { text: "What you want to recycle " },
    { text: "Material  " },
    { text: "Your location (Optional) " },
    { text: "Condition " },
    { text: "Choose Recycle or Reuse  " },
    { text: "Recycling Instructions:Material: {{material of product}}Location: {{user's location (if provided)}}Specific steps for recycling the product based on material and location.Alternative options for disposal if recycling is not possible.Explanation of why certain steps are necessary.Local resources: Links to local recycling guidelines, recycling centers, and drop-off locations.Additional Information:Environmental benefits of recycling the product.Safety precautions when handling the product.FAQs about recycling the product.Creative reuse ideas for the product. ADD reusable instruction in detailed way. Prioritize reusability when applicable:Check the \"Condition of product\" input: If it's good, prioritize reuse instructions before recycling.Offer various reuse options:Reusability based on original purpose:Explain how to clean and maintain the product for continued use.Suggest alternative uses within the same category (e.g., using a food container for storage).Creative upcycling ideas:Provide links to DIY project tutorials or inspirational examples.Highlight the environmental and economic benefits of upcycling.Donation options:List local organizations that accept donations of specific items in good condition.Include information on donation preparation and drop-off locations.Structure the reuse instructions:Use a dedicated section with a clear heading like \"Reuse Options\" or \"Before You Recycle.\"For each reuse option, provide:A concise description: Summarize the reuse idea in a few words.Detailed steps: Clearly explain the process (e.g., cleaning methods, upcycling instructions).Visuals: Include images or diagrams to enhance understanding .Safety tips: Address any potential safety concerns related to reuse." },
    { text: "What you want to recycle Bottle" },
    { text: "Material  Plastic" },
    { text: "Your location (Optional) NYC" },
    { text: "Condition Good" },
    { text: "Choose Recycle or Reuse  Recycle" },
    { text: " " },
  ];
  const chatHistory = [
    {
      role: "user",
      parts: parts,
    },
  ];

  const chat = model.startChat({
    generationConfig,
    safetySettings,
    history: chatHistory,
  });

  try {
    const result = await chat.sendMessage(userInput);
    const response = result.response;
    return response.text();
  } catch (error) {
    console.error('Error in sending message to Generative AI:', error);
    throw error; // Rethrow the error to handle it appropriately in the calling code
  }
}

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

app.get('/loader.gif', (req, res) => {
  res.sendFile(__dirname + '/loader.gif');
});

app.post('/chat', async (req, res) => {
  try {
    const userInput = req.body?.userInput;
    console.log('incoming /chat req', userInput)
    if (!userInput) {
      return res.status(400).json({ error: 'Invalid request body' });
    }

    const response = await runChat(userInput);
    res.json({ response });
  } catch (error) {
    console.error('Error in chat endpoint:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});